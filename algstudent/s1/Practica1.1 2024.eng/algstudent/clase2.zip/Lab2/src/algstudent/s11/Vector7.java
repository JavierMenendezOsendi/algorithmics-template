package algstudent.s11;

public class Vector7 {
	
	
	

}
