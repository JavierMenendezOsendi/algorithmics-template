package algstudent;

public class NumericSquareAll {

}
