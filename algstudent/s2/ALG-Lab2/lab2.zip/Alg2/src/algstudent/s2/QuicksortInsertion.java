package algstudent.s2;

public class QuicksortInsertion {
	
	static int[] v;
	
	public static void quickSortInsertion(int[] a, int left, int right) {
		int j;
		int pivot;
		int n = a.length;
		
		for (int i =  1; i < n; i++) {
			pivot = a[i];
			j = i-1;
			
			while (j >= 0 && pivot < a[j]) {
				a[j+1] = a[j];
				j--;
			}
			
			a[j+1] = pivot;
		}
	}
	
	public static void quicksort(int[] a) {
		quickSortInsertion(a, 0, a.length-1);
	}

	public static void main(String arg[]) {
		int n = 16000000;
		v = new int[n];

		Vector.randomSorted(v);
		System.out.println("VECTOR TO BE SORTED");
		Vector.print(v);
		quicksort(v);
		System.out.println("SORTED VECTOR");
		Vector.print(v);
	} 

}
